//
//  ViewController.swift
//  Haystax iOS Sample
//
//  Created by Akbar Sattar on 1/9/19.
//  Copyright © 2019 Akbar Sattar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var linkData: Links.Link?
    var dataSelector: Int = 0
// Outlets
    
    // Link ID
    @IBOutlet weak var idDisplay: UILabel!
    
    // From Elements
    @IBOutlet weak var fromTitle: UILabel!
    @IBOutlet weak var fromId: UILabel!
    @IBOutlet weak var fromCollection: UILabel!
    
    //To Elements 
    @IBOutlet weak var toTitle: UILabel!
    @IBOutlet weak var toCollection: UILabel!
    @IBOutlet weak var toId: UILabel!
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Run function to parse json, input of dataSelector to decide which Link to show. Default value of dataSelector is 0, so we start at the beginning of the list
        getJsonFromUrl(dataSelector: self.dataSelector)
        
    }
    
    // Iterate forward through list of objects when pressing "Next" button. Currently, this does not link up to to/from properly but is just here to show proof of concept
    @IBAction func nextObjButton(_ sender: Any) {
       
        // We have a list of 3 items , so make sure we don't get to the end of the list by checking the current value of dataSelector
        if  self.dataSelector < 2 {
            // Add dataSelector to move forwards in the list
        self.dataSelector = self.dataSelector + 1
        
        getJsonFromUrl(dataSelector: self.dataSelector)
            print (self.dataSelector)
        
        } else {
        
        //Show error box  if we've reached the end
        let alert = UIAlertController(title: "Oops!", message: "You've reached the end of the list. Press Previous Button to go backwards", preferredStyle: UIAlertController.Style.alert)
        
        alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.default, handler: nil))
        
        self.present(alert, animated: true, completion: nil) }
        
    }
    
    
    // Iterate backwards through the list of objects when pressing "Prev" button. Currently it does not link up to to/from properly but is here to show proof of concept
    @IBAction func prevObjButton(_ sender: Any) {
        
        // Make sure we don't get past the beginning of the list by checking the current value of dataSelector
        if  self.dataSelector > 0 {
            //Subtract dataSelector to move backwards in the list
            self.dataSelector = self.dataSelector - 1
            
            getJsonFromUrl(dataSelector: self.dataSelector)
            print (self.dataSelector)
        } else {
        
        //Show error box  if we've reached the beginning
        let alert = UIAlertController(title: "Oops!", message: "You've reached the beginning of the list. Press Next Button to go Forwards", preferredStyle: UIAlertController.Style.alert)
        
        alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.default, handler: nil))
        
        self.present(alert, animated: true, completion: nil) }
    }
    
    func getJsonFromUrl(dataSelector: Int){
        
        
        // Get JSON from URL and decode it into type Links (Collection of type Link)
        let url = URL(string: "https://api.myjson.com/bins/19o9y0")!
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let data = data, error == nil,
                let links = try? JSONDecoder().decode(Links.self, from: data)
                // We have an error, task is not complete
                else { print("Could not parse JSON. Error: \(String(describing: error?.localizedDescription))")
                    return }
            
            // Make an Link object with the data we parsed from JSON using the index passed by dataSelector. This allows us to draw the index we need.
            
            self.linkData = links.links[dataSelector]
            
            
            //call updateUi() after giving it main thread
            DispatchQueue.main.async {
                self.updateUi()
            }
            
        
            }.resume()
       
    }
    
    
    
    func updateUi() {
        // Set Link ID

        idDisplay.text = self.linkData?.id
        print(self.linkData?.id)

        //Set from info
        fromTitle.text = self.linkData?.from.title
        fromId.text = self.linkData?.from.objid
        fromCollection.text = self.linkData?.from.collection
        
        //Set to info
        toTitle.text = self.linkData?.to.title
        toId.text = self.linkData?.to.objid
        toCollection.text = self.linkData?.to.collection
        
    }

    
   
}

