//
//  Link.swift
//  Haystax iOS Sample
//
//  Created by Akbar Sattar on 1/9/19.
//  Copyright © 2019 Akbar Sattar. All rights reserved.
//

import Foundation

// Since the JSON provides us with an array of Links, we make an object for a collection of Links
class Links: Codable {
    let links: [Link]
    
    init(links: [Link]){
        self.links = links
    }
    
// Object for Individual links, which consist of an ID , From object, and To object
    class Link: Codable {
        let direction: String
        let from: From
        let id: String
        let to: To
        
        init(direction: String , from :From, id: String, to: To ) {
            
            self.direction = direction
            self.from = from
            self.id = id
            self.to = to
        }
    }
    
}

// From object that contains Objid , collection and Title
struct From : Codable {
    let objid: String
    let collection: String
    let title: String
    
    enum CodingKeys: String, CodingKey {
        case objid = "objid"
        case collection = "collection"
        case title = "title"
    }
}

// To object that contains the same items
struct To : Codable {
    let objid: String
    let collection: String
    let title: String
        
    enum CodingKeys: String, CodingKey {
        case objid = "objid"
        case collection = "collection"
        case title = "title"
        }
    
}



