//
//  ViewController.swift
//  Haystax iOS Sample
//
//  Created by Akbar Sattar on 1/9/19.
//  Copyright © 2019 Akbar Sattar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var linkData: Links.Link?
// Outlets
    
    // Link ID
    @IBOutlet weak var idDisplay: UILabel!
    
    // From Elements
    @IBOutlet weak var fromTitle: UILabel!
    @IBOutlet weak var fromId: UILabel!
    @IBOutlet weak var fromCollection: UILabel!
    
    //To Elements 
    @IBOutlet weak var toTitle: UILabel!
    @IBOutlet weak var toCollection: UILabel!
    @IBOutlet weak var toId: UILabel!
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Run function to parse json
        getJsonFromUrl()
        
    }
    
    
    func getJsonFromUrl(){
        
        
        // Get JSON from URL and decode it into type Links (Collection of type Link)
        let url = URL(string: "https://api.myjson.com/bins/19o9y0")!
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let data = data, error == nil,
                let links = try? JSONDecoder().decode(Links.self, from: data)
                // We have an error, task is not complete
                else { print("Could not parse JSON. Error: \(String(describing: error?.localizedDescription))")
                    return }
            
            // Make an object with the data we parsed from JSON. Since we collected all 3 links, for the purposes of this project will just use the first one or Index 0. We then assign the value to the class-wide variable
            self.linkData = links.links[0]
            
            
            //updateUi() after giving it main thread
            DispatchQueue.main.async {
                self.updateUi()
            }
            
        
            }.resume()
       
    }
    
    
    
    func updateUi() {
        // Set Link ID

        idDisplay.text = self.linkData?.id
        print(self.linkData?.id)

        //Set from info
        fromTitle.text = self.linkData?.from.title
        fromId.text = self.linkData?.from.objid
        fromCollection.text = self.linkData?.from.collection
        
        //Set to info
        toTitle.text = self.linkData?.to.title
        toId.text = self.linkData?.to.objid
        toCollection.text = self.linkData?.to.collection
        
    }

    
   
}

